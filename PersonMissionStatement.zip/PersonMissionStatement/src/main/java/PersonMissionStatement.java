import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.*;
import javax.swing.*;

public class PersonMissionStatement extends javax.swing.JFrame {

    private boolean isAnimating = false;
    private final int PANEL_WIDTH = 540;

    public PersonMissionStatement() {
        initComponents();
        this.setResizable(false);
        setLocationRelativeTo(null);

        // Ensure only the CoverPage is visible at launch
        jPanel1.setVisible(false);
        jPanel2.setVisible(false);
        jPanel3.setVisible(false);
        jPanel4.setVisible(false);
        jPanel5.setVisible(false);

        // Make navigation buttons transparent
        transparentButton(Next);
        transparentButton(Previous1); transparentButton(Next1);
        transparentButton(Previous2); transparentButton(Next2);
        transparentButton(Previous3); transparentButton(Next3);
        transparentButton(Previous4); transparentButton(Next4);
        transparentButton(Previous5);

        this.pack();
    }

    public void transparentButton(JButton button) {
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
    }

    // Implements simultaneous slide: oldPanel slides out left, newPanel slides in left
    private void setNextPanel(final JPanel oldPanel, final JPanel newPanel) {
        if (isAnimating) {
            return;
        }
        isAnimating = true;

        final Container parent = oldPanel.getParent();
        parent.setLayout(null);

        if (newPanel.getParent() == null) {
            parent.add(newPanel);
        }

        parent.setComponentZOrder(newPanel, 0);
        parent.setComponentZOrder(oldPanel, 1);

        newPanel.setBounds(PANEL_WIDTH, 0, PANEL_WIDTH, oldPanel.getHeight());
        newPanel.setVisible(true);

        Timer timer = new Timer(10, new ActionListener() {
            int xOffset = 0;
            final int step = 10;

            public void actionPerformed(ActionEvent e) {
                if (xOffset < PANEL_WIDTH) {
                    xOffset += step;
                    if (xOffset > PANEL_WIDTH) {
                        xOffset = PANEL_WIDTH;
                    }

                    // Old panel slides out to the left
                    oldPanel.setLocation(-xOffset, oldPanel.getY());

                    // New panel slides in to the left
                    newPanel.setLocation(PANEL_WIDTH - xOffset, newPanel.getY());

                    // Force repaint during animation
                    parent.revalidate();
                    parent.repaint();

                } else {
                    ((Timer) e.getSource()).stop();

                    // Final Cleanup
                    newPanel.setLocation(0, 0);
                    oldPanel.setVisible(false);
                    isAnimating = false;

                    parent.revalidate();
                    parent.repaint();
                }
            }
        });
        timer.start();
    }

    // Implements simultaneous slide: oldPanel slides out right, newPanel slides in right
    private void setPreviousPanel(final JPanel oldPanel, final JPanel newPanel) {

        if (isAnimating) {
            return;
        }
        isAnimating = true;

        final Container parent = oldPanel.getParent();
        parent.setLayout(null);

        if (newPanel.getParent() == null) {
            parent.add(newPanel);
        }

        parent.setComponentZOrder(newPanel, 0);
        parent.setComponentZOrder(oldPanel, 1);

        newPanel.setBounds(-PANEL_WIDTH, 0, PANEL_WIDTH, oldPanel.getHeight());
        newPanel.setVisible(true);

        Timer timer = new Timer(10, new ActionListener() {
            int xOffset = 0; // Tracks the movement distance from 0
            final int step = 10;

            public void actionPerformed(ActionEvent e) {
                if (xOffset < PANEL_WIDTH) {
                    xOffset += step;
                    if (xOffset > PANEL_WIDTH) {
                        xOffset = PANEL_WIDTH;
                    }

                    // Old panel slides out to the right
                    oldPanel.setLocation(xOffset, oldPanel.getY());

                    // New panel slides in to the right
                    newPanel.setLocation(-PANEL_WIDTH + xOffset, newPanel.getY());

                    // Force repaint during animation
                    parent.revalidate();
                    parent.repaint();
                } else {
                    ((Timer) e.getSource()).stop();

                    // Final Cleanup
                    newPanel.setLocation(0, 0);
                    oldPanel.setVisible(false);
                    isAnimating = false;

                    parent.revalidate();
                    parent.repaint();
                }
            }
        });
        timer.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CoverPage = new javax.swing.JPanel();
        Name = new javax.swing.JLabel();
        School = new javax.swing.JLabel();
        Task = new javax.swing.JLabel();
        Year = new javax.swing.JLabel();
        Next = new javax.swing.JButton();
        Background = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Previous1 = new javax.swing.JButton();
        Next1 = new javax.swing.JButton();
        jTextArea1 = new javax.swing.JTextArea();
        Background1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        Previous2 = new javax.swing.JButton();
        Next2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTextArea2 = new javax.swing.JTextArea();
        Background2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        Previous3 = new javax.swing.JButton();
        Next3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextArea3 = new javax.swing.JTextArea();
        Background3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        Previous4 = new javax.swing.JButton();
        Next4 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jTextArea4 = new javax.swing.JTextArea();
        Background4 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        Previous5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextArea5 = new javax.swing.JTextArea();
        Background5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Person Mission Statement");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setMaximumSize(new java.awt.Dimension(540, 800));
        setMinimumSize(new java.awt.Dimension(540, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CoverPage.setMaximumSize(new java.awt.Dimension(540, 800));
        CoverPage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Name.setFont(new java.awt.Font("Monospaced", 0, 36)); // NOI18N
        Name.setForeground(javax.swing.UIManager.getDefaults().getColor("text"));
        Name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Name.setText("CHINASA NWOSU");
        CoverPage.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, 410, 50));

        School.setFont(new java.awt.Font("Monospaced", 0, 30)); // NOI18N
        School.setForeground(javax.swing.UIManager.getDefaults().getColor("text"));
        School.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        School.setText("SACRED HEART COLLEGE");
        CoverPage.add(School, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 410, 50));

        Task.setFont(new java.awt.Font("Monospaced", 0, 25)); // NOI18N
        Task.setForeground(javax.swing.UIManager.getDefaults().getColor("text"));
        Task.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Task.setText("PERSONAL MISSION STATEMENT");
        CoverPage.add(Task, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, -1, 50));

        Year.setFont(new java.awt.Font("Monospaced", 0, 30)); // NOI18N
        Year.setForeground(javax.swing.UIManager.getDefaults().getColor("text"));
        Year.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Year.setText("YEAR 2025");
        CoverPage.add(Year, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 410, 50));

        Next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foward.png"))); // NOI18N
        Next.setPreferredSize(new java.awt.Dimension(45, 45));
        Next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextActionPerformed(evt);
            }
        });
        CoverPage.add(Next, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 710, -1, -1));

        Background.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CoverPage.png"))); // NOI18N
        Background.setMaximumSize(new java.awt.Dimension(540, 800));
        Background.setMinimumSize(new java.awt.Dimension(540, 800));
        Background.setPreferredSize(new java.awt.Dimension(540, 800));
        CoverPage.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 800));

        getContentPane().add(CoverPage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.setMaximumSize(new java.awt.Dimension(540, 800));
        jPanel1.setMinimumSize(new java.awt.Dimension(540, 800));
        jPanel1.setPreferredSize(new java.awt.Dimension(540, 800));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Previous1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        Previous1.setPreferredSize(new java.awt.Dimension(50, 50));
        Previous1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Previous1ActionPerformed(evt);
            }
        });
        jPanel1.add(Previous1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 710, -1, -1));

        Next1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foward.png"))); // NOI18N
        Next1.setPreferredSize(new java.awt.Dimension(50, 50));
        Next1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Next1ActionPerformed(evt);
            }
        });
        jPanel1.add(Next1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 710, -1, -1));

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new Color(30,30,30,0));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Bradley Hand ITC", 1, 25)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(5, 5, 6));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setTabSize(5);
        jTextArea1.setText("As I prepare to leave school and step into the \nworld as a young adult, my immediate future\nbringing more independence and \nresponsibility, it also brongs an opportunity \nto grow, learn, and shape me into the person I \nwant to be.");
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setFocusable(false);
        jPanel1.add(jTextArea1, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 170, 540, 250));

        Background1.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pages.png"))); // NOI18N
        jPanel1.add(Background1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel2.setMaximumSize(new java.awt.Dimension(540, 800));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Previous2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        Previous2.setPreferredSize(new java.awt.Dimension(50, 50));
        Previous2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Previous2ActionPerformed(evt);
            }
        });
        jPanel2.add(Previous2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 710, -1, -1));

        Next2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foward.png"))); // NOI18N
        Next2.setPreferredSize(new java.awt.Dimension(50, 50));
        Next2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Next2ActionPerformed(evt);
            }
        });
        jPanel2.add(Next2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 710, -1, -1));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/personal.png"))); // NOI18N
        jLabel1.setToolTipText("Personal Views");
        jLabel1.setPreferredSize(new java.awt.Dimension(90, 90));
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 40, -1, -1));

        jTextArea2.setEditable(false);
        jTextArea2.setBackground(new Color(30,30,30,0));
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Bradley Hand ITC", 1, 25)); // NOI18N
        jTextArea2.setForeground(new java.awt.Color(5, 5, 6));
        jTextArea2.setLineWrap(true);
        jTextArea2.setRows(5);
        jTextArea2.setTabSize(5);
        jTextArea2.setText("I believe that life is not just about achieving success for myself, but also about using my skills and talents to make a difference in the lives of others. I a challenge as an opportunity to build strength, discipline, and character. I believe that every stage of life prepares me for the next.");
        jTextArea2.setWrapStyleWord(true);
        jTextArea2.setFocusable(false);
        jPanel2.add(jTextArea2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 540, 230));

        Background2.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pages.png"))); // NOI18N
        jPanel2.add(Background2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel3.setMaximumSize(new java.awt.Dimension(540, 800));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Previous3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        Previous3.setPreferredSize(new java.awt.Dimension(50, 50));
        Previous3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Previous3ActionPerformed(evt);
            }
        });
        jPanel3.add(Previous3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 710, -1, -1));

        Next3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foward.png"))); // NOI18N
        Next3.setPreferredSize(new java.awt.Dimension(50, 50));
        Next3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Next3ActionPerformed(evt);
            }
        });
        jPanel3.add(Next3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 710, -1, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/church.png"))); // NOI18N
        jLabel2.setToolTipText("Religion and Ideologies");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 40, -1, -1));

        jTextArea3.setEditable(false);
        jTextArea3.setBackground(new Color(30,30,30,0));
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Bradley Hand ITC", 1, 25)); // NOI18N
        jTextArea3.setForeground(new java.awt.Color(5, 5, 6));
        jTextArea3.setLineWrap(true);
        jTextArea3.setRows(5);
        jTextArea3.setTabSize(5);
        jTextArea3.setText("My Christian faith is the foundation of everything I do. I believe God created me for a purpose and blessed me with gifts to serve others and in moments of doubt, I turn to prayer “For I know the plans I have for you,” declares the Lord... “plans to give you hope and a future” (Jeremiah 29:11). I strive to live humbly, remembering that all I achieve should honor God.\n\nI value integrity, creativity, and hard work.  “Whatever you do, work at it with all your heart, as working for the Lord...” (Colossians 3:23). These values shape how I approach both my goals and the challenges I face.");
        jTextArea3.setWrapStyleWord(true);
        jTextArea3.setFocusable(false);
        jPanel3.add(jTextArea3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 540, 490));

        Background3.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pages.png"))); // NOI18N
        jPanel3.add(Background3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel4.setMaximumSize(new java.awt.Dimension(540, 800));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Previous4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        Previous4.setPreferredSize(new java.awt.Dimension(50, 50));
        Previous4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Previous4ActionPerformed(evt);
            }
        });
        jPanel4.add(Previous4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 710, -1, -1));

        Next4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foward.png"))); // NOI18N
        Next4.setMaximumSize(null);
        Next4.setMinimumSize(null);
        Next4.setPreferredSize(new java.awt.Dimension(50, 50));
        Next4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Next4ActionPerformed(evt);
            }
        });
        jPanel4.add(Next4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 710, -1, -1));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/globe.png"))); // NOI18N
        jLabel3.setToolTipText("Lifestyle and Environmental Responsiblility");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 40, -1, -1));

        jTextArea4.setEditable(false);
        jTextArea4.setBackground(new Color(30,30,30,0));
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Bradley Hand ITC", 1, 25)); // NOI18N
        jTextArea4.setForeground(new java.awt.Color(5, 5, 6));
        jTextArea4.setLineWrap(true);
        jTextArea4.setRows(5);
        jTextArea4.setTabSize(5);
        jTextArea4.setText("I strive for a balanced life—working hard while staying rooted in faith, health, and purpose. Discipline keeps me focused, and I believe caring for the environment is part of honoring God’s creation. In my IT journey, I hope to support green, sustainable solutions. As the Bible says, “Whatever you do, do it all for the glory of God.” — 1 Corinthians 10:31");
        jTextArea4.setWrapStyleWord(true);
        jTextArea4.setFocusable(false);
        jPanel4.add(jTextArea4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 540, 270));

        Background4.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pages.png"))); // NOI18N
        jPanel4.add(Background4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel5.setMaximumSize(new java.awt.Dimension(540, 800));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Previous5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back.png"))); // NOI18N
        Previous5.setPreferredSize(new java.awt.Dimension(50, 50));
        Previous5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Previous5ActionPerformed(evt);
            }
        });
        jPanel5.add(Previous5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 710, -1, -1));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/globe.png"))); // NOI18N
        jLabel4.setToolTipText("Goals for Studies and Career Choices");
        jPanel5.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(225, 40, -1, -1));

        jTextArea5.setEditable(false);
        jTextArea5.setBackground(new Color(30,30,30,0));
        jTextArea5.setColumns(20);
        jTextArea5.setFont(new java.awt.Font("Bradley Hand ITC", 1, 25)); // NOI18N
        jTextArea5.setForeground(new java.awt.Color(5, 5, 6));
        jTextArea5.setLineWrap(true);
        jTextArea5.setRows(5);
        jTextArea5.setTabSize(5);
        jTextArea5.setText("After Matric, I plan to pursue an education mainly in software development and cybersecurity.\nAs Steve Jobs said, “The people who are crazy enough to think they can change the world are the ones who do.”\nAs I progress, I aim to specialize in either Cybersecurity or Software Development, with the long-term goal of using my expertise to create impactful solutions that improve people's lives.\n");
        jTextArea5.setWrapStyleWord(true);
        jTextArea5.setFocusable(false);
        jPanel5.add(jTextArea5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 540, 370));

        Background5.setFont(new java.awt.Font("Maiandra GD", 0, 24)); // NOI18N
        Background5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pages.png"))); // NOI18N
        jPanel5.add(Background5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NextActionPerformed(java.awt.event.ActionEvent evt) {
        setNextPanel(CoverPage, jPanel1);
    }

    private void Next1ActionPerformed(java.awt.event.ActionEvent evt) {
        setNextPanel(jPanel1, jPanel2);
    }

    private void Previous1ActionPerformed(java.awt.event.ActionEvent evt) {
        setPreviousPanel(jPanel1, CoverPage);
    }

    private void Previous2ActionPerformed(java.awt.event.ActionEvent evt) {
        setPreviousPanel(jPanel2, jPanel1);
    }

    private void Next2ActionPerformed(java.awt.event.ActionEvent evt) {
        setNextPanel(jPanel2, jPanel3);
    }

    private void Previous3ActionPerformed(java.awt.event.ActionEvent evt) {
        setPreviousPanel(jPanel3, jPanel2);
    }

    private void Next3ActionPerformed(java.awt.event.ActionEvent evt) {
        setNextPanel(jPanel3, jPanel4);
    }

    private void Previous4ActionPerformed(java.awt.event.ActionEvent evt) {
        setPreviousPanel(jPanel4, jPanel3);
    }

    private void Next4ActionPerformed(java.awt.event.ActionEvent evt) {
        setNextPanel(jPanel4, jPanel5);
    }

    private void Previous5ActionPerformed(java.awt.event.ActionEvent evt) {
        setPreviousPanel(jPanel5, jPanel4);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
            SwingUtilities.updateComponentTreeUI(new PersonMissionStatement());
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(PersonMissionStatement.class.getName()).log(Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PersonMissionStatement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JLabel Background1;
    private javax.swing.JLabel Background2;
    private javax.swing.JLabel Background3;
    private javax.swing.JLabel Background4;
    private javax.swing.JLabel Background5;
    private javax.swing.JPanel CoverPage;
    private javax.swing.JLabel Name;
    private javax.swing.JButton Next;
    private javax.swing.JButton Next1;
    private javax.swing.JButton Next2;
    private javax.swing.JButton Next3;
    private javax.swing.JButton Next4;
    private javax.swing.JButton Previous1;
    private javax.swing.JButton Previous2;
    private javax.swing.JButton Previous3;
    private javax.swing.JButton Previous4;
    private javax.swing.JButton Previous5;
    private javax.swing.JLabel School;
    private javax.swing.JLabel Task;
    private javax.swing.JLabel Year;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    // End of variables declaration//GEN-END:variables
}
